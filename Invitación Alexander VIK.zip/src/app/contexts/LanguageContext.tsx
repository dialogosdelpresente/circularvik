import { createContext, useContext, useState, ReactNode } from "react";

type Language = "es" | "en";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations: Record<Language, Record<string, string>> = {
  es: {
    // Hero
    "hero.subtitle": "Un ecosistema probado. Un nuevo territorio. La misma visión.",
    "hero.surface": "Superficie",
    "hero.value": "Valor de referencia",
    "hero.location": "Ubicación",
    "hero.maitencillo": "Maitencillo, Chile",
    
    // System Circles
    "circles.title": "Sistema Territorial",
    "circles.region": "Región",
    "circles.hotel": "Hotel Vik Maitencillo",
    "circles.vina": "Viña Vik",
    "circles.community": "Comunidad",
    "circles.future": "Futuro",
    
    // Region
    "region.title": "Maitencillo · Región de Valparaíso",
    "region.desc": "Un territorio donde confluyen mar, viento, topografía y clima mediterráneo. Sistema natural que ya contiene las condiciones para una arquitectura dialogante.",
    
    // Hotel Project
    "hotel.title": "Hotel Vik Maitencillo",
    "hotel.subtitle": "Proyecto Propuesto",
    "hotel.desc": "Núcleo del sistema. Arquitectura integrada al paisaje, permeable, sostenible. No un objeto aislado, sino una plataforma territorial que conecta naturaleza, comunidad y visión de largo plazo.",
    
    // Viña Vik
    "vina.title": "Viña Vik",
    "vina.subtitle": "Un estándar ya construido. Una visión ya validada.",
    "vina.desc": "Sistema consolidado que integra arquitectura de excelencia, paisaje, arte y territorio. Referencia viva de lo que significa crear valor sistémico de largo plazo.",
    "vina.tour": "Explorar Viña Vik",
    
    // Community
    "community.title": "Comunidad & Entorno",
    "community.desc": "La comunidad local como stakeholder real. Economía integrada, escala humana, inclusión verdadera. El territorio prospera cuando todos prosperan.",
    
    // Future
    "future.title": "Expansión Natural",
    "future.desc": "Replicabilidad del modelo Vik. Cada proyecto fortalece el ecosistema completo, creando valor sostenible que trasciende fronteras.",
    
    // Map
    "map.title": "Territorio Real",
    "map.subtitle": "Ubicación exacta del terreno propuesto",
    "map.viewVik": "Ver relación con Viña Vik",
    "map.connection": "De un ecosistema consolidado a su expansión natural hacia otro territorio",
    
    // Formal Invitation
    "invitation.title": "Invitación Formal",
    "invitation.text": "Invitamos respetuosamente al Sr. Alexander Vik a considerar la adquisición de este terreno, con el propósito de destinarlo a la expansión del ecosistema Vik, dando continuidad a los criterios que han definido Hotel y Viña Vik desde su origen: arquitectura de excelencia, sostenibilidad real, visión sistémica y diálogo profundo con el territorio.",
    
    // Vision
    "vision.title": "Visión Fundacional",
    "vision.text": "Todo proyecto verdaderamente exitoso es sistémico. Cuando el territorio, la comunidad, la naturaleza y el capital prosperan juntos, el valor se multiplica de forma sostenible en el tiempo.",
    
    // Components
    "components.title": "Hotel Vik 2 · Componentes Sistémicos",
    "components.arch": "Arquitectura integrada al paisaje",
    "components.vineyard": "Viñedos orgánicos del entorno",
    "components.regen": "Agricultura regenerativa",
    "components.food": "Producción local de alimentos",
    "components.art": "Arte y land art",
    "components.circular": "Economía circular",
    "components.energy": "Energía limpia",
    "components.community": "Comunidad como stakeholder real",
    "components.financial": "Rentabilidad financiera de largo plazo",
    "components.message": "Nada aislado. Todo interconectado.",
    
    // Adjacent Lots
    "adjacent.title": "Lotes Adyacentes",
    "adjacent.subtitle": "Opcional · No Vinculante",
    "adjacent.text": "Tenemos el privilegio de contar con la representación de dos lotes adyacentes adicionales, que, sumados al primer terreno, abren la posibilidad —si resultara de interés para sus objetivos— de desarrollar proyectos complementarios, sostenibles, circulares y financieramente rentables.",
    "adjacent.note": "Totalmente opcional. No vinculante con el Proyecto 1. Siempre como extensión dialogante, nunca como fragmentación.",
    
    // Strategic Alliance
    "alliance.title": "Alianza Estratégica y Red de Apoyo",
    "alliance.text": "Ponemos desde ya a disposición, mediante alianza estratégica, nuestra red internacional de contactos, que abarca desde Land Art Generator Initiative, hasta Foro Económico Mundial / Centro para la Cuarta Revolución Industrial, por mencionar solo dos ejemplos, para apoyar el desarrollo de proyectos alineados con una visión sostenible, circular y de largo plazo.",
    
    // CTA
    "cta.explore": "Explorar la visión",
    "cta.territory": "Ver el territorio",
    "cta.conversation": "Continuar la conversación",
  },
  en: {
    // Hero
    "hero.subtitle": "A proven ecosystem. A new territory. The same vision.",
    "hero.surface": "Surface Area",
    "hero.value": "Reference Value",
    "hero.location": "Location",
    "hero.maitencillo": "Maitencillo, Chile",
    
    // System Circles
    "circles.title": "Territorial System",
    "circles.region": "Region",
    "circles.hotel": "Hotel Vik Maitencillo",
    "circles.vina": "Viña Vik",
    "circles.community": "Community",
    "circles.future": "Future",
    
    // Region
    "region.title": "Maitencillo · Valparaíso Region",
    "region.desc": "A territory where sea, wind, topography and Mediterranean climate converge. Natural system already containing the conditions for dialogic architecture.",
    
    // Hotel Project
    "hotel.title": "Hotel Vik Maitencillo",
    "hotel.subtitle": "Proposed Project",
    "hotel.desc": "System nucleus. Architecture integrated into landscape, permeable, sustainable. Not an isolated object, but a territorial platform connecting nature, community and long-term vision.",
    
    // Viña Vik
    "vina.title": "Viña Vik",
    "vina.subtitle": "An already built standard. An already validated vision.",
    "vina.desc": "Consolidated system integrating architectural excellence, landscape, art and territory. Living reference of what it means to create systemic long-term value.",
    "vina.tour": "Explore Viña Vik",
    
    // Community
    "community.title": "Community & Environment",
    "community.desc": "Local community as real stakeholder. Integrated economy, human scale, true inclusion. Territory thrives when everyone thrives.",
    
    // Future
    "future.title": "Natural Expansion",
    "future.desc": "Replicability of the Vik model. Each project strengthens the entire ecosystem, creating sustainable value that transcends borders.",
    
    // Map
    "map.title": "Real Territory",
    "map.subtitle": "Exact location of proposed land",
    "map.viewVik": "View relationship with Viña Vik",
    "map.connection": "From a consolidated ecosystem to its natural expansion into another territory",
    
    // Formal Invitation
    "invitation.title": "Formal Invitation",
    "invitation.text": "We respectfully invite Mr. Alexander Vik to consider acquiring this land, with the purpose of dedicating it to the expansion of the Vik ecosystem, continuing the criteria that have defined Hotel and Viña Vik since their origin: architectural excellence, real sustainability, systemic vision and deep dialogue with the territory.",
    
    // Vision
    "vision.title": "Foundational Vision",
    "vision.text": "Every truly successful project is systemic. When territory, community, nature and capital prosper together, value multiplies sustainably over time.",
    
    // Components
    "components.title": "Hotel Vik 2 · Systemic Components",
    "components.arch": "Architecture integrated into landscape",
    "components.vineyard": "Organic vineyards in surroundings",
    "components.regen": "Regenerative agriculture",
    "components.food": "Local food production",
    "components.art": "Art and land art",
    "components.circular": "Circular economy",
    "components.energy": "Clean energy",
    "components.community": "Community as real stakeholder",
    "components.financial": "Long-term financial profitability",
    "components.message": "Nothing isolated. Everything interconnected.",
    
    // Adjacent Lots
    "adjacent.title": "Adjacent Lots",
    "adjacent.subtitle": "Optional · Non-Binding",
    "adjacent.text": "We have the privilege of representing two additional adjacent lots, which, combined with the first land, open the possibility —if of interest to your objectives— of developing complementary, sustainable, circular and financially profitable projects.",
    "adjacent.note": "Completely optional. Non-binding with Project 1. Always as dialogic extension, never as fragmentation.",
    
    // Strategic Alliance
    "alliance.title": "Strategic Alliance and Support Network",
    "alliance.text": "We make available, through strategic alliance, our international network of contacts, ranging from Land Art Generator Initiative to World Economic Forum / Center for the Fourth Industrial Revolution, to name just two examples, to support the development of projects aligned with a sustainable, circular and long-term vision.",
    
    // CTA
    "cta.explore": "Explore the vision",
    "cta.territory": "View the territory",
    "cta.conversation": "Continue the conversation",
  }
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("es");

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider");
  }
  return context;
}
