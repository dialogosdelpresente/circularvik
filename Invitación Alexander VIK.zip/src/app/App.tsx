import { LanguageProvider } from "./contexts/LanguageContext";
import { VikNavbar } from "./components/vik/VikNavbar";
import { VikHero } from "./components/vik/VikHero";
import { VisionSection } from "./components/vik/VisionSection";
import { InteractiveCircles } from "./components/vik/InteractiveCircles";
import { VikTour } from "./components/vik/VikTour";
import { MapSection } from "./components/vik/MapSection";
import { FormalInvitation } from "./components/vik/FormalInvitation";
import { ComponentsSection } from "./components/vik/ComponentsSection";
import { AdjacentLots } from "./components/vik/AdjacentLots";
import { StrategicAlliance } from "./components/vik/StrategicAlliance";
import { CTASection } from "./components/vik/CTASection";
import { VikFooter } from "./components/vik/Footer";

export default function App() {
  return (
    <LanguageProvider>
      <div className="min-h-screen bg-white antialiased">
        <VikNavbar />
        <VikHero />
        <VisionSection />
        <InteractiveCircles />
        <VikTour />
        <ComponentsSection />
        <MapSection />
        <FormalInvitation />
        <AdjacentLots />
        <StrategicAlliance />
        <CTASection />
        <VikFooter />
      </div>
    </LanguageProvider>
  );
}
