import { motion } from "motion/react";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";

const tourImages = [
  {
    url: "https://images.unsplash.com/photo-1646320557112-e5b38e6369e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3RlbCUyMHZpayUyMGNoaWxlJTIwYXJjaGl0ZWN0dXJlfGVufDF8fHx8MTc2ODI0MDEzNXww&ixlib=rb-4.1.0&q=80&w=1080",
    caption: "Arquitectura"
  },
  {
    url: "https://images.unsplash.com/photo-1580681900294-6805c94a70b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwYXJjaGl0ZWN0dXJlJTIwbGFuZHNjYXBlfGVufDF8fHx8MTc2ODI0MDEzNXww&ixlib=rb-4.1.0&q=80&w=1080",
    caption: "Paisaje"
  },
  {
    url: "https://images.unsplash.com/photo-1766325629329-c98e07e26e25?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMGludGVyaW9yJTIwYXJ0fGVufDF8fHx8MTc2ODI0MDEzN3ww&ixlib=rb-4.1.0&q=80&w=1080",
    caption: "Interior · Arte"
  },
  {
    url: "https://images.unsplash.com/photo-1752253509808-1ccbbebdeb25?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW5leWFyZCUyMGFyY2hpdGVjdHVyZSUyMG1vZGVybnxlbnwxfHx8fDE3NjgyNDAxMzZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    caption: "Viñedo"
  },
  {
    url: "https://images.unsplash.com/photo-1584276586563-ea31e8f360d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXN0YWluYWJsZSUyMGFyY2hpdGVjdHVyZSUyMG5hdHVyZXxlbnwxfHx8fDE3NjgyMTYwODN8MA&ixlib=rb-4.1.0&q=80&w=1080",
    caption: "Sostenibilidad"
  },
  {
    url: "https://images.unsplash.com/photo-1616094173085-7294a4e55477?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYW5kJTIwYXJ0JTIwbGFuZHNjYXBlfGVufDF8fHx8MTc2ODI0MDEzOHww&ixlib=rb-4.1.0&q=80&w=1080",
    caption: "Land Art"
  }
];

export function VikTour() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { t } = useLanguage();

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % tourImages.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + tourImages.length) % tourImages.length);
  };

  return (
    <section className="py-32 px-8 bg-[#1A1A1A] text-white">
      <div className="max-w-[1400px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-center mb-16"
        >
          <p className="text-[#9B9B9B] text-xs tracking-[0.3em] uppercase mb-4">
            Viña Vik
          </p>
          <h2 className="text-3xl md:text-4xl mb-4 font-light">
            {t("vina.subtitle")}
          </h2>
        </motion.div>

        {/* Image Gallery */}
        <div className="relative">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="aspect-[16/9] max-w-5xl mx-auto relative overflow-hidden"
          >
            <img
              src={tourImages[currentIndex].url}
              alt={tourImages[currentIndex].caption}
              className="w-full h-full object-cover"
            />
            
            {/* Caption */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-8">
              <p className="text-sm tracking-[0.2em] uppercase text-[#E8E3DB]">
                {tourImages[currentIndex].caption}
              </p>
            </div>
          </motion.div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-8 mt-12">
            <button
              onClick={prev}
              className="w-12 h-12 border border-white/30 hover:border-white hover:bg-white hover:text-[#1A1A1A] transition-all duration-300 flex items-center justify-center"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <div className="flex gap-2">
              {tourImages.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentIndex
                      ? "bg-white w-8"
                      : "bg-white/30 hover:bg-white/50"
                  }`}
                />
              ))}
            </div>

            <button
              onClick={next}
              className="w-12 h-12 border border-white/30 hover:border-white hover:bg-white hover:text-[#1A1A1A] transition-all duration-300 flex items-center justify-center"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Counter */}
          <p className="text-center mt-6 text-[#9B9B9B] text-sm tracking-wider">
            {String(currentIndex + 1).padStart(2, "0")} / {String(tourImages.length).padStart(2, "0")}
          </p>
        </div>
      </div>
    </section>
  );
}
