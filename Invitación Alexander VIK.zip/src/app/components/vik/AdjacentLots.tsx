import { motion } from "motion/react";
import { useLanguage } from "../../contexts/LanguageContext";

export function AdjacentLots() {
  const { t } = useLanguage();

  return (
    <section className="py-32 px-8 bg-[#FAFAF8]">
      <div className="max-w-[1000px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2 }}
          className="space-y-8"
        >
          <div className="text-center">
            <p className="text-[#9B9B9B] text-xs tracking-[0.3em] uppercase mb-2">
              {t("adjacent.title")}
            </p>
            <p className="text-[#6B7F6E] text-sm tracking-wide">
              {t("adjacent.subtitle")}
            </p>
          </div>

          <div className="bg-white border border-[#E8E3DB] p-10">
            <p className="text-[#1A1A1A] leading-relaxed text-lg mb-8">
              {t("adjacent.text")}
            </p>

            <div className="bg-[#FAFAF8] p-6 border-l-2 border-[#6B7F6E]">
              <p className="text-sm text-[#1A1A1A] leading-relaxed">
                {t("adjacent.note")}
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
