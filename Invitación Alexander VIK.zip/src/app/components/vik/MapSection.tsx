import { motion } from "motion/react";
import { useState } from "react";
import { MapPin, ExternalLink } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";

export function MapSection() {
  const [showConnection, setShowConnection] = useState(false);
  const { t } = useLanguage();

  return (
    <section className="py-32 px-8 bg-white">
      <div className="max-w-[1400px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-center mb-16"
        >
          <p className="text-[#9B9B9B] text-xs tracking-[0.3em] uppercase mb-4">
            {t("map.title")}
          </p>
          <h2 className="text-3xl md:text-4xl mb-4 font-light text-[#1A1A1A]">
            {t("map.subtitle")}
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Map Embed */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="relative"
          >
            <div className="aspect-[4/3] bg-[#E8E3DB] border border-[#9B9B9B]/30 overflow-hidden">
              {/* Google Maps Embed */}
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13203.162850862885!2d-71.4563!3d-32.7504!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzLCsDQ1JzAxLjQiUyA3McKwMjcnMjIuNyJX!5e0!3m2!1sen!2scl!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Maitencillo Location"
              />
            </div>

            <a
              href="https://maps.app.goo.gl/Gnj4rwEEbTSFEaRH6"
              target="_blank"
              rel="noopener noreferrer"
              className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-4 py-2 text-sm text-[#1A1A1A] border border-[#E8E3DB] hover:bg-[#1A1A1A] hover:text-white transition-all duration-300 flex items-center gap-2"
            >
              <MapPin className="w-4 h-4" />
              <span>Ver en Maps</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </motion.div>

          {/* Info Panel */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="space-y-8"
          >
            <div className="bg-[#FAFAF8] p-8 border border-[#E8E3DB]">
              <h3 className="text-xl mb-4 font-light text-[#1A1A1A]">
                Maitencillo
              </h3>
              <p className="text-[#1A1A1A] leading-relaxed mb-6">
                Costa central de Chile, Región de Valparaíso. Territorio donde confluyen
                océano Pacífico, clima mediterráneo, topografía ondulada y comunidad
                consolidada.
              </p>

              <div className="space-y-3 text-sm">
                <div className="flex justify-between py-2 border-b border-[#E8E3DB]">
                  <span className="text-[#9B9B9B]">Coordenadas</span>
                  <span className="text-[#1A1A1A]">32°45'S 71°27'W</span>
                </div>
                <div className="flex justify-between py-2 border-b border-[#E8E3DB]">
                  <span className="text-[#9B9B9B]">Distancia Santiago</span>
                  <span className="text-[#1A1A1A]">140 km</span>
                </div>
                <div className="flex justify-between py-2 border-b border-[#E8E3DB]">
                  <span className="text-[#9B9B9B]">Vista al mar</span>
                  <span className="text-[#1A1A1A]">Directa</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-[#9B9B9B]">Acceso</span>
                  <span className="text-[#1A1A1A]">Ruta F-30-E</span>
                </div>
              </div>
            </div>

            {/* Connection Button */}
            <button
              onClick={() => setShowConnection(!showConnection)}
              className="w-full bg-[#6B7F6E] text-white py-4 px-6 hover:bg-[#1A1A1A] transition-all duration-300 text-sm tracking-wide"
            >
              {t("map.viewVik")}
            </button>

            {showConnection && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-[#1A1A1A] text-white p-8"
              >
                <p className="text-sm leading-relaxed text-[#E8E3DB]">
                  {t("map.connection")}
                </p>
                <div className="mt-6 pt-6 border-t border-white/20 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-[#9B9B9B]">Viña Vik</span>
                    <span>Millahue, VI Región</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#9B9B9B]">Distancia</span>
                    <span>~320 km</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#9B9B9B]">Ecosistemas</span>
                    <span>Complementarios</span>
                  </div>
                </div>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
