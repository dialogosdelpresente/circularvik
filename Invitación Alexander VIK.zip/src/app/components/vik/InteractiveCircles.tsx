import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { X } from "lucide-react";

type CircleType = "region" | "hotel" | "vina" | "community" | "future" | null;

const circleData = {
  region: {
    size: 400,
    position: { x: 50, y: 50 },
    color: "#E8E3DB",
    stroke: "#9B9B9B"
  },
  hotel: {
    size: 180,
    position: { x: 50, y: 50 },
    color: "#6B7F6E",
    stroke: "#1A1A1A"
  },
  vina: {
    size: 140,
    position: { x: 28, y: 60 },
    color: "#2C3E50",
    stroke: "#1A1A1A"
  },
  community: {
    size: 120,
    position: { x: 72, y: 42 },
    color: "#9B9B9B",
    stroke: "#6B7F6E"
  },
  future: {
    size: 160,
    position: { x: 50, y: 22 },
    color: "transparent",
    stroke: "#9B9B9B"
  }
};

export function InteractiveCircles() {
  const [selected, setSelected] = useState<CircleType>(null);
  const { t } = useLanguage();

  return (
    <section className="py-32 px-8 bg-white">
      <div className="max-w-[1400px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-center mb-20"
        >
          <p className="text-[#9B9B9B] text-xs tracking-[0.3em] uppercase mb-4">
            {t("circles.title")}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* SVG Circles */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2 }}
            className="relative aspect-square max-w-[600px] mx-auto"
          >
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {/* Region Circle - Base */}
              <motion.circle
                cx={circleData.region.position.x}
                cy={circleData.region.position.y}
                r={circleData.region.size / 10}
                fill={circleData.region.color}
                stroke={circleData.region.stroke}
                strokeWidth="0.1"
                className="cursor-pointer transition-all duration-500"
                whileHover={{ scale: 1.02, opacity: 0.9 }}
                onClick={() => setSelected("region")}
              />

              {/* Hotel Circle - Center */}
              <motion.circle
                cx={circleData.hotel.position.x}
                cy={circleData.hotel.position.y}
                r={circleData.hotel.size / 10}
                fill={circleData.hotel.color}
                fillOpacity="0.3"
                stroke={circleData.hotel.stroke}
                strokeWidth="0.2"
                className="cursor-pointer transition-all duration-500"
                whileHover={{ scale: 1.05, fillOpacity: 0.5 }}
                onClick={() => setSelected("hotel")}
              />

              {/* Viña Vik Circle */}
              <motion.circle
                cx={circleData.vina.position.x}
                cy={circleData.vina.position.y}
                r={circleData.vina.size / 10}
                fill={circleData.vina.color}
                fillOpacity="0.7"
                stroke={circleData.vina.stroke}
                strokeWidth="0.2"
                className="cursor-pointer transition-all duration-500"
                whileHover={{ scale: 1.05, fillOpacity: 0.9 }}
                onClick={() => setSelected("vina")}
              />

              {/* Community Circle */}
              <motion.circle
                cx={circleData.community.position.x}
                cy={circleData.community.position.y}
                r={circleData.community.size / 10}
                fill={circleData.community.color}
                fillOpacity="0.2"
                stroke={circleData.community.stroke}
                strokeWidth="0.15"
                className="cursor-pointer transition-all duration-500"
                whileHover={{ scale: 1.05, fillOpacity: 0.4 }}
                onClick={() => setSelected("community")}
              />

              {/* Future Circle */}
              <motion.circle
                cx={circleData.future.position.x}
                cy={circleData.future.position.y}
                r={circleData.future.size / 10}
                fill={circleData.future.color}
                stroke={circleData.future.stroke}
                strokeWidth="0.1"
                strokeDasharray="1,1"
                className="cursor-pointer transition-all duration-500"
                whileHover={{ scale: 1.05, strokeWidth: 0.15 }}
                onClick={() => setSelected("future")}
              />

              {/* Labels */}
              <text
                x={circleData.region.position.x}
                y={circleData.region.position.y + circleData.region.size / 10 + 3}
                textAnchor="middle"
                className="text-[0.8px] fill-[#9B9B9B] tracking-wider uppercase"
                style={{ fontSize: "0.8px" }}
              >
                {t("circles.region")}
              </text>

              <text
                x={circleData.hotel.position.x}
                y={circleData.hotel.position.y}
                textAnchor="middle"
                className="text-[1px] fill-white font-light tracking-wide"
                style={{ fontSize: "1px" }}
              >
                Hotel Vik
              </text>

              <text
                x={circleData.vina.position.x}
                y={circleData.vina.position.y}
                textAnchor="middle"
                className="text-[0.9px] fill-white tracking-wide"
                style={{ fontSize: "0.9px" }}
              >
                Viña Vik
              </text>
            </svg>
          </motion.div>

          {/* Content Panel */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2 }}
            className="relative min-h-[400px]"
          >
            <AnimatePresence mode="wait">
              {selected ? (
                <motion.div
                  key={selected}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.5 }}
                  className="bg-[#FAFAF8] p-10 border border-[#E8E3DB]"
                >
                  <button
                    onClick={() => setSelected(null)}
                    className="absolute top-4 right-4 text-[#9B9B9B] hover:text-[#1A1A1A] transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>

                  <h3 className="text-2xl text-[#1A1A1A] mb-2 font-light">
                    {t(`${selected}.title`)}
                  </h3>
                  
                  {selected === "vina" && (
                    <p className="text-[#6B7F6E] text-sm mb-4 tracking-wide">
                      {t(`${selected}.subtitle`)}
                    </p>
                  )}
                  
                  {selected === "hotel" && (
                    <p className="text-[#6B7F6E] text-sm mb-4 tracking-wide">
                      {t(`${selected}.subtitle`)}
                    </p>
                  )}

                  <p className="text-[#1A1A1A] leading-relaxed mb-6">
                    {t(`${selected}.desc`)}
                  </p>

                  {selected === "vina" && (
                    <button className="text-sm text-[#6B7F6E] border border-[#6B7F6E] px-6 py-2 hover:bg-[#6B7F6E] hover:text-white transition-all duration-300">
                      {t("vina.tour")}
                    </button>
                  )}
                </motion.div>
              ) : (
                <motion.div
                  key="placeholder"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex items-center justify-center h-full text-[#9B9B9B] text-center"
                >
                  <p className="text-sm tracking-wide">
                    Selecciona un círculo para explorar
                    <br />
                    <span className="text-xs">Select a circle to explore</span>
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
