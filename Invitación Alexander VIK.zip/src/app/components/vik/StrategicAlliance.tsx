import { motion } from "motion/react";
import { useLanguage } from "../../contexts/LanguageContext";
import { Network, Globe, Sparkles } from "lucide-react";

export function StrategicAlliance() {
  const { t } = useLanguage();

  return (
    <section className="py-32 px-8 bg-[#1A1A1A] text-white">
      <div className="max-w-[1200px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2 }}
          className="space-y-12"
        >
          <div className="text-center">
            <p className="text-[#9B9B9B] text-xs tracking-[0.3em] uppercase mb-8">
              {t("alliance.title")}
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-10">
            <p className="text-lg leading-relaxed text-[#E8E3DB] mb-12">
              {t("alliance.text")}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center space-y-4">
                <div className="w-16 h-16 border border-white/20 mx-auto flex items-center justify-center">
                  <Sparkles className="w-7 h-7 text-[#E8E3DB]" />
                </div>
                <p className="text-sm text-[#9B9B9B]">
                  Land Art Generator
                  <br />
                  Initiative
                </p>
              </div>

              <div className="text-center space-y-4">
                <div className="w-16 h-16 border border-white/20 mx-auto flex items-center justify-center">
                  <Globe className="w-7 h-7 text-[#E8E3DB]" />
                </div>
                <p className="text-sm text-[#9B9B9B]">
                  World Economic Forum
                  <br />
                  C4IR
                </p>
              </div>

              <div className="text-center space-y-4">
                <div className="w-16 h-16 border border-white/20 mx-auto flex items-center justify-center">
                  <Network className="w-7 h-7 text-[#E8E3DB]" />
                </div>
                <p className="text-sm text-[#9B9B9B]">
                  Red Internacional
                  <br />
                  Sostenibilidad
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
