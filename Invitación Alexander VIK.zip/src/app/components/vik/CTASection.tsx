import { motion } from "motion/react";
import { useLanguage } from "../../contexts/LanguageContext";
import { ArrowRight } from "lucide-react";

export function CTASection() {
  const { t } = useLanguage();

  return (
    <section className="py-32 px-8 bg-white">
      <div className="max-w-[800px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2 }}
          className="text-center space-y-8"
        >
          <div className="space-y-6">
            <button className="group border border-[#1A1A1A] px-8 py-4 hover:bg-[#1A1A1A] hover:text-white transition-all duration-500 inline-flex items-center gap-3">
              <span className="text-sm tracking-wider">{t("cta.explore")}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="border border-[#6B7F6E] text-[#6B7F6E] px-6 py-3 hover:bg-[#6B7F6E] hover:text-white transition-all duration-300 text-sm tracking-wide">
                {t("cta.territory")}
              </button>
              <button className="border border-[#9B9B9B] text-[#9B9B9B] px-6 py-3 hover:bg-[#9B9B9B] hover:text-white transition-all duration-300 text-sm tracking-wide">
                {t("cta.conversation")}
              </button>
            </div>
          </div>

          <div className="pt-12">
            <div className="w-32 h-[1px] bg-gradient-to-r from-transparent via-[#9B9B9B] to-transparent mx-auto" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
