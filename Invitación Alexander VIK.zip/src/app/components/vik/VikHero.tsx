import { motion } from "motion/react";
import { useLanguage } from "../../contexts/LanguageContext";

export function VikHero() {
  const { t } = useLanguage();

  return (
    <section className="min-h-screen bg-[#FAFAF8] flex items-center justify-center px-8 pt-24 pb-16">
      <div className="max-w-[1200px] w-full">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.3 }}
          className="text-center mb-20"
        >
          <p className="text-[#6B7F6E] text-sm tracking-[0.4em] uppercase mb-8 font-light">
            Private
          </p>
          <h2 className="text-4xl md:text-6xl text-[#1A1A1A] mb-12 leading-tight font-light max-w-4xl mx-auto">
            {t("hero.subtitle")}
          </h2>
        </motion.div>

        {/* Key Data */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-12 max-w-5xl mx-auto"
        >
          <div className="text-center border-l border-[#E8E3DB] pl-8">
            <p className="text-[#9B9B9B] text-xs tracking-[0.3em] uppercase mb-3">
              {t("hero.surface")}
            </p>
            <p className="text-3xl text-[#1A1A1A] font-light">38,500 m²</p>
          </div>

          <div className="text-center border-l border-[#E8E3DB] pl-8">
            <p className="text-[#9B9B9B] text-xs tracking-[0.3em] uppercase mb-3">
              {t("hero.value")}
            </p>
            <p className="text-3xl text-[#1A1A1A] font-light">USD 9,000,000</p>
          </div>

          <div className="text-center border-l border-[#E8E3DB] pl-8">
            <p className="text-[#9B9B9B] text-xs tracking-[0.3em] uppercase mb-3">
              {t("hero.location")}
            </p>
            <p className="text-3xl text-[#1A1A1A] font-light">
              {t("hero.maitencillo")}
            </p>
          </div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
          className="text-center mt-24"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <div className="w-[1px] h-16 bg-gradient-to-b from-transparent via-[#9B9B9B] to-transparent mx-auto" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
