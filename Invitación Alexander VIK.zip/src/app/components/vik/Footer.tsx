import { motion } from "motion/react";

export function VikFooter() {
  return (
    <footer className="py-16 px-8 bg-[#1A1A1A] text-white border-t border-white/10">
      <div className="max-w-[1400px] mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <h3 className="text-2xl tracking-[0.2em] font-light mb-2">VIK</h3>
            <p className="text-[#9B9B9B] text-xs tracking-wider">
              Ecosistema · 2026
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.2 }}
            className="text-center md:text-right"
          >
            <p className="text-[#9B9B9B] text-xs tracking-wider mb-2">
              Private Presentation
            </p>
            <p className="text-[#9B9B9B] text-xs">
              Alexander Vik · Strategic Vision
            </p>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.4 }}
          className="mt-12 pt-8 border-t border-white/10 text-center"
        >
          <p className="text-[#9B9B9B] text-xs">
            Confidencial · No Público
          </p>
        </motion.div>
      </div>
    </footer>
  );
}
