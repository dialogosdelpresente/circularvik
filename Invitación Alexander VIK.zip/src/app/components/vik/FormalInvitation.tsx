import { motion } from "motion/react";
import { useLanguage } from "../../contexts/LanguageContext";

export function FormalInvitation() {
  const { t } = useLanguage();

  return (
    <section className="py-32 px-8 bg-[#2C3E50] text-white">
      <div className="max-w-[1000px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2 }}
          className="space-y-12"
        >
          <div className="text-center">
            <p className="text-[#E8E3DB] text-xs tracking-[0.3em] uppercase mb-8">
              {t("invitation.title")}
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-12">
            <p className="text-lg md:text-xl leading-relaxed text-[#E8E3DB] font-light text-center">
              {t("invitation.text")}
            </p>
          </div>

          <div className="text-center pt-8">
            <div className="inline-block">
              <div className="w-64 h-[1px] bg-gradient-to-r from-transparent via-white/30 to-transparent" />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
