import { motion } from "motion/react";
import { useLanguage } from "../../contexts/LanguageContext";

export function VikNavbar() {
  const { language, setLanguage } = useLanguage();

  return (
    <motion.nav
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 1, ease: "easeOut" }}
      className="fixed top-0 left-0 right-0 z-50 bg-[#FAFAF8]/95 backdrop-blur-sm border-b border-[#E8E3DB]"
    >
      <div className="max-w-[1400px] mx-auto px-8 py-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 1 }}
          >
            <h1 className="text-2xl tracking-[0.2em] text-[#1A1A1A] font-light">
              VIK
            </h1>
          </motion.div>

          {/* Language Switch */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="flex gap-2 border border-[#9B9B9B]/30 rounded-sm overflow-hidden"
          >
            <button
              onClick={() => setLanguage("es")}
              className={`px-4 py-2 text-sm tracking-wider transition-all duration-300 ${
                language === "es"
                  ? "bg-[#1A1A1A] text-[#FAFAF8]"
                  : "bg-transparent text-[#9B9B9B] hover:text-[#1A1A1A]"
              }`}
            >
              ES
            </button>
            <button
              onClick={() => setLanguage("en")}
              className={`px-4 py-2 text-sm tracking-wider transition-all duration-300 ${
                language === "en"
                  ? "bg-[#1A1A1A] text-[#FAFAF8]"
                  : "bg-transparent text-[#9B9B9B] hover:text-[#1A1A1A]"
              }`}
            >
              EN
            </button>
          </motion.div>
        </div>
      </div>
    </motion.nav>
  );
}
