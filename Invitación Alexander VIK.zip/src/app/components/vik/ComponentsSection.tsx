import { motion } from "motion/react";
import { useLanguage } from "../../contexts/LanguageContext";
import {
  Home,
  Grape,
  Sprout,
  Utensils,
  Palette,
  Recycle,
  Zap,
  Users,
  TrendingUp
} from "lucide-react";

export function ComponentsSection() {
  const { t } = useLanguage();

  const components = [
    { icon: Home, key: "arch" },
    { icon: Grape, key: "vineyard" },
    { icon: Sprout, key: "regen" },
    { icon: Utensils, key: "food" },
    { icon: Palette, key: "art" },
    { icon: Recycle, key: "circular" },
    { icon: Zap, key: "energy" },
    { icon: Users, key: "community" },
    { icon: TrendingUp, key: "financial" }
  ];

  return (
    <section className="py-32 px-8 bg-white">
      <div className="max-w-[1400px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-center mb-20"
        >
          <p className="text-[#9B9B9B] text-xs tracking-[0.3em] uppercase mb-4">
            {t("components.title")}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {components.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.key}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.05 }}
                className="group"
              >
                <div className="border border-[#E8E3DB] p-8 hover:border-[#6B7F6E] transition-all duration-500 h-full">
                  <div className="w-12 h-12 border border-[#9B9B9B] flex items-center justify-center mb-6 group-hover:bg-[#6B7F6E] group-hover:border-[#6B7F6E] group-hover:text-white transition-all duration-300">
                    <Icon className="w-5 h-5" />
                  </div>
                  <p className="text-[#1A1A1A] leading-relaxed">
                    {t(`components.${item.key}`)}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-center"
        >
          <p className="text-2xl text-[#1A1A1A] font-light italic">
            {t("components.message")}
          </p>
        </motion.div>
      </div>
    </section>
  );
}
