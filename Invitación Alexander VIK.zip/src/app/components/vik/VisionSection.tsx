import { motion } from "motion/react";
import { useLanguage } from "../../contexts/LanguageContext";

export function VisionSection() {
  const { t } = useLanguage();

  return (
    <section className="py-32 px-8 bg-[#FAFAF8]">
      <div className="max-w-[900px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2 }}
          className="text-center"
        >
          <p className="text-[#9B9B9B] text-xs tracking-[0.3em] uppercase mb-8">
            {t("vision.title")}
          </p>
          
          <p className="text-2xl md:text-3xl text-[#1A1A1A] leading-relaxed font-light">
            {t("vision.text")}
          </p>

          <div className="mt-16 w-32 h-[1px] bg-gradient-to-r from-transparent via-[#9B9B9B] to-transparent mx-auto" />
        </motion.div>
      </div>
    </section>
  );
}
